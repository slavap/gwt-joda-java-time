import plug from '../../'

function test_plug() {
    plug({})
}
