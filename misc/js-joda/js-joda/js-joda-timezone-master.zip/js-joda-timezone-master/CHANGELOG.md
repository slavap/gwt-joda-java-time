Changelog
=========

### 1.1.7 (next)

### 1.1.6

#### dependendency updates

#### etc

 * private export of tzdb data

### 1.1.5

#### etc
 
 * add bower.json

#### dependendency updates

### 1.1.3

#### dependendency updates

* incliuding moment-timezone@0.5.13 iana tzdb 2017b

### 1.1.2

#### add typescript definition

#### dependency updates
  
### 1.1.1

last release without a CHANGELOG.md 
