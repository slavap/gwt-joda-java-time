module.exports = {
    'extends': 'eslint-config-js-joda',
};