import latest from '../data/packed/latest.json';

export default latest;
