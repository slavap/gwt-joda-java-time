require('./suites/parse');
require('./suites/now');
require('./suites/plus1Day');
require('./suites/plusMinusDaysAndHours');
require('./suites/isLeapYear');
require('./suites/weekOfWeekYear');
