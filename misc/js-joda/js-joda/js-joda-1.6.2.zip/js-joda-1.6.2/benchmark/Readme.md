js-joda Benckmarks
==================


## Install 

Clone these repository, change into the directory benchmark `cd benchmark` and execute `npm install`
 
 
## Run benchmarks with node

```

# run all benchmark
node runAllTests.js

# run a single benchmark
node suites/plus1ay.js

```

## Execute benchmarks in a browser

just `open runAllTests.html` in a browser

